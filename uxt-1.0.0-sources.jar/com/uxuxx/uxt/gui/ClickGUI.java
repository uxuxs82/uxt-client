package com.uxuxx.uxt.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.uxuxx.uxt.Module;
import com.uxuxx.uxt.UXTClient;
import java.util.List;
import net.minecraft.class_2585;
import net.minecraft.class_437;
import net.minecraft.class_4587;

public class ClickGUI extends class_437 {
    
    private int dragX = 50;
    private int dragY = 50;
    private boolean dragging = false;
    private int dragOffsetX;
    private int dragOffsetY;
    private Module expandedModule = null;
    
    // Double click detection
    private Module lastClickedModule = null;
    private long lastClickTime = 0;
    private static final long DOUBLE_CLICK_DELAY = 500; // milliseconds
    
    private static final int COLUMN_WIDTH = 150;
    private static final int MODULE_HEIGHT = 18;
    private static final int HEADER_HEIGHT = 20;
    private static final int SETTING_HEIGHT = 16;
    private static final int MODULES_PER_COLUMN = 9;
    
    public ClickGUI() {
        super(new class_2585("UXT"));
    }
    
    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        List<Module> modules = UXTClient.moduleManager.getModules();
        int totalColumns = (int) Math.ceil((double) modules.size() / MODULES_PER_COLUMN);
        int totalWidth = totalColumns * COLUMN_WIDTH;
        
        // Calculate max height for expanded module
        int maxHeight = HEADER_HEIGHT + MODULES_PER_COLUMN * MODULE_HEIGHT;
        if (expandedModule != null && !expandedModule.getSettings().isEmpty()) {
            maxHeight += expandedModule.getSettings().size() * SETTING_HEIGHT;
        }
        
        // Header
        method_25294(matrices, dragX, dragY, dragX + totalWidth, dragY + HEADER_HEIGHT, 0xFF1a1a1a);
        method_25300(matrices, field_22793, "UXT Client - Press X or Z", dragX + totalWidth / 2, dragY + 6, 0xFFFFFF);
        
        // Background
        method_25294(matrices, dragX, dragY + HEADER_HEIGHT, dragX + totalWidth, dragY + maxHeight, 0xE0101010);
        
        // Draw modules in columns
        int moduleIndex = 0;
        for (int col = 0; col < totalColumns; col++) {
            int colX = dragX + col * COLUMN_WIDTH;
            int yOffset = dragY + HEADER_HEIGHT;
            
            for (int row = 0; row < MODULES_PER_COLUMN && moduleIndex < modules.size(); row++, moduleIndex++) {
                Module module = modules.get(moduleIndex);
                
                // Module background
                int bgColor = module.isEnabled() ? 0xFF2a2a2a : 0xFF1a1a1a;
                method_25294(matrices, colX + 2, yOffset + 2, colX + COLUMN_WIDTH - 2, yOffset + MODULE_HEIGHT - 2, bgColor);
                
                // Module name
                int textColor = module.isEnabled() ? 0x00FF00 : 0xAAAAAA;
                String name = module.getName();
                if (field_22793.method_1727(name) > COLUMN_WIDTH - 30) {
                    name = name.substring(0, Math.min(name.length(), 10)) + "..";
                }
                field_22793.method_1729(matrices, name, colX + 8, yOffset + 6, textColor);
                
                // Settings indicator
                if (!module.getSettings().isEmpty()) {
                    String arrow = module == expandedModule ? "v" : ">";
                    field_22793.method_1729(matrices, arrow, colX + COLUMN_WIDTH - 15, yOffset + 6, 0xAAAAAA);
                }
                
                // Draw settings if expanded (only for last column to avoid overlap)
                if (module == expandedModule && !module.getSettings().isEmpty() && col == totalColumns - 1) {
                    int settingY = yOffset + MODULE_HEIGHT;
                    for (Module.Setting setting : module.getSettings()) {
                        method_25294(matrices, colX + 10, settingY + 2, colX + COLUMN_WIDTH - 10, settingY + SETTING_HEIGHT - 2, 0xFF0a0a0a);
                        
                        // Setting name and value
                        String settingText = setting.getName() + ": " + String.format("%.1f", setting.getValue());
                        field_22793.method_1729(matrices, settingText, colX + 15, settingY + 5, 0xCCCCCC);
                        
                        // Slider bar
                        int sliderX = colX + 15;
                        int sliderY = settingY + SETTING_HEIGHT - 5;
                        int sliderWidth = COLUMN_WIDTH - 30;
                        
                        method_25294(matrices, sliderX, sliderY, sliderX + sliderWidth, sliderY + 2, 0xFF555555);
                        
                        double percent = (setting.getValue() - setting.getMin()) / (setting.getMax() - setting.getMin());
                        int filledWidth = (int)(sliderWidth * percent);
                        method_25294(matrices, sliderX, sliderY, sliderX + filledWidth, sliderY + 2, 0xFF00FF00);
                        
                        settingY += SETTING_HEIGHT;
                    }
                }
                
                yOffset += MODULE_HEIGHT;
            }
        }
        
        super.method_25394(matrices, mouseX, mouseY, delta);
    }
    
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        List<Module> modules = UXTClient.moduleManager.getModules();
        int totalColumns = (int) Math.ceil((double) modules.size() / MODULES_PER_COLUMN);
        int totalWidth = totalColumns * COLUMN_WIDTH;
        int maxHeight = HEADER_HEIGHT + MODULES_PER_COLUMN * MODULE_HEIGHT;
        
        // Check header drag
        if (mouseX >= dragX && mouseX <= dragX + totalWidth && mouseY >= dragY && mouseY <= dragY + HEADER_HEIGHT) {
            dragging = true;
            dragOffsetX = (int)(mouseX - dragX);
            dragOffsetY = (int)(mouseY - dragY);
            return true;
        }
        
        // Check module clicks
        int moduleIndex = 0;
        for (int col = 0; col < totalColumns; col++) {
            int colX = dragX + col * COLUMN_WIDTH;
            int yOffset = dragY + HEADER_HEIGHT;
            
            for (int row = 0; row < MODULES_PER_COLUMN && moduleIndex < modules.size(); row++, moduleIndex++) {
                Module module = modules.get(moduleIndex);
                
                // Check module click
                if (mouseX >= colX && mouseX <= colX + COLUMN_WIDTH && 
                    mouseY >= yOffset && mouseY <= yOffset + MODULE_HEIGHT) {
                    if (button == 0) { // Left click
                        long currentTime = System.currentTimeMillis();
                        
                        // Check for double click
                        if (module == lastClickedModule && 
                            currentTime - lastClickTime < DOUBLE_CLICK_DELAY &&
                            !module.getSettings().isEmpty()) {
                            // Double click - open settings
                            expandedModule = expandedModule == module ? null : module;
                            lastClickedModule = null;
                            lastClickTime = 0;
                        } else {
                            // Single click - toggle module
                            module.toggle();
                            lastClickedModule = module;
                            lastClickTime = currentTime;
                        }
                    }
                    return true;
                }
                
                yOffset += MODULE_HEIGHT;
                
                // Check setting slider clicks (only for last column)
                if (module == expandedModule && !module.getSettings().isEmpty() && col == totalColumns - 1) {
                    for (Module.Setting setting : module.getSettings()) {
                        int sliderX = colX + 15;
                        int sliderY = yOffset + SETTING_HEIGHT - 5;
                        int sliderWidth = COLUMN_WIDTH - 30;
                        
                        if (mouseX >= sliderX && mouseX <= sliderX + sliderWidth && 
                            mouseY >= yOffset && mouseY <= yOffset + SETTING_HEIGHT) {
                            
                            double percent = (mouseX - sliderX) / sliderWidth;
                            double newValue = setting.getMin() + percent * (setting.getMax() - setting.getMin());
                            setting.setValue(newValue);
                            return true;
                        }
                        
                        yOffset += SETTING_HEIGHT;
                    }
                }
            }
        }
        
        return super.method_25402(mouseX, mouseY, button);
    }
    
    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        dragging = false;
        return super.method_25406(mouseX, mouseY, button);
    }
    
    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging) {
            dragX = (int)(mouseX - dragOffsetX);
            dragY = (int)(mouseY - dragOffsetY);
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }
    
    public boolean shouldPauseGame() {
        return false;
    }
}
