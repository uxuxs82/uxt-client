package com.uxuxx.uxt.mixin;

import com.uxuxx.uxt.UXTClient;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2248.class)
public class BlockMixin {
    
    @Inject(method = "shouldDrawSide", at = @At("HEAD"), cancellable = true)
    private static void onShouldDrawSide(class_2680 state, class_1922 world, class_2338 pos, class_2350 side, CallbackInfoReturnable<Boolean> cir) {
        boolean xrayEnabled = UXTClient.moduleManager.getModules().stream()
            .anyMatch(m -> m.getName().equals("Xray") && m.isEnabled());
        
        if (xrayEnabled) {
            class_2248 block = state.method_26204();
            if (block == class_2246.field_10442 || block == class_2246.field_10212 || 
                block == class_2246.field_10571 || block == class_2246.field_10013 ||
                block == class_2246.field_10418 || block == class_2246.field_10080 ||
                block == class_2246.field_10090 || block == class_2246.field_10213 ||
                block == class_2246.field_22109) {
                cir.setReturnValue(true);
            } else {
                cir.setReturnValue(false);
            }
        }
    }
}
