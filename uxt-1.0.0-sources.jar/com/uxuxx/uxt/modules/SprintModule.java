package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_310;

public class SprintModule extends Module {
    
    public SprintModule() {
        super("Sprint");
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        
        if (client.field_1724.field_3913.field_3905 > 0 && !client.field_1724.method_5715()) {
            client.field_1724.method_5728(true);
        }
    }
}
