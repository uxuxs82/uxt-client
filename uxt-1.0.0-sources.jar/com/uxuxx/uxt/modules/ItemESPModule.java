package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_310;

public class ItemESPModule extends Module {
    
    private Setting rangeSetting;
    
    public ItemESPModule() {
        super("ItemESP");
        rangeSetting = new Setting("Range", 32.0, 16.0, 64.0, 8.0);
        settings.add(rangeSetting);
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null || client.field_1687 == null) return;
        
        // Highlight dropped items - rendering handled by mixin
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (entity instanceof class_1542) {
                double dist = client.field_1724.method_5739(entity);
                if (dist <= rangeSetting.getValue()) {
                    entity.method_5834(true);
                }
            }
        }
    }
    
    @Override
    public void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1687 != null) {
            for (class_1297 entity : client.field_1687.method_18112()) {
                if (entity instanceof class_1542) {
                    entity.method_5834(false);
                }
            }
        }
    }
}
