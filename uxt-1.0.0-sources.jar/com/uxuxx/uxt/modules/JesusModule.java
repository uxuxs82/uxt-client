package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class JesusModule extends Module {
    
    public JesusModule() {
        super("Jesus");
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        
        // Walk on water
        class_2338 below = client.field_1724.method_24515().method_10074();
        if (client.field_1687.method_8320(below).method_26227().method_15771() || 
            client.field_1687.method_8320(below).method_26227().method_15769() == false) {
            
            if (client.field_1724.method_5799() && !client.field_1724.method_5715()) {
                class_243 velocity = client.field_1724.method_18798();
                client.field_1724.method_18800(velocity.field_1352, 0.1, velocity.field_1350);
                client.field_1724.field_6017 = 0;
            }
        }
    }
}
