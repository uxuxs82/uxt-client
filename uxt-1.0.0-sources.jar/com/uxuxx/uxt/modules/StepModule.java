package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_310;

public class StepModule extends Module {
    
    private Setting heightSetting;
    
    public StepModule() {
        super("Step");
        heightSetting = new Setting("Height", 1.0, 0.5, 2.0, 0.5);
        settings.add(heightSetting);
    }
    
    @Override
    public void onEnable() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.field_6013 = (float) heightSetting.getValue();
        }
    }
    
    @Override
    public void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.field_6013 = 0.6f;
        }
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        client.field_1724.field_6013 = (float) heightSetting.getValue();
    }
}
