package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_310;

public class ESPModule extends Module {
    
    public ESPModule() {
        super("ESP");
    }
    
    @Override
    public void onEnable() {
        class_310 client = class_310.method_1551();
        if (client.field_1687 != null) {
            client.field_1769.method_3279();
        }
    }
    
    @Override
    public void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1687 != null) {
            client.field_1769.method_3279();
        }
    }
    
    @Override
    public void onTick(class_310 client) {
        // ESP rendering handled by mixin
    }
}
