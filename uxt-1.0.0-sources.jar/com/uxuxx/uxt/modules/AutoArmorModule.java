package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_1304;
import net.minecraft.class_1713;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_310;

public class AutoArmorModule extends Module {
    
    private int tickCounter = 0;
    
    public AutoArmorModule() {
        super("AutoArmor");
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        
        tickCounter++;
        if (tickCounter < 40) return;
        tickCounter = 0;
        
        for (int i = 0; i < 4; i++) {
            class_1304 slot = class_1304.values()[i + 2]; // HEAD, CHEST, LEGS, FEET
            class_1799 current = client.field_1724.method_6118(slot);
            
            int bestSlot = findBestArmor(client, i);
            if (bestSlot != -1) {
                client.field_1761.method_2906(0, bestSlot, 0, class_1713.field_7794, client.field_1724);
            }
        }
    }
    
    private int findBestArmor(class_310 client, int armorType) {
        int bestSlot = -1;
        int bestProtection = -1;
        
        for (int i = 0; i < client.field_1724.field_7514.method_5439(); i++) {
            class_1799 stack = client.field_1724.field_7514.method_5438(i);
            if (stack.method_7909() instanceof class_1738) {
                class_1738 armor = (class_1738) stack.method_7909();
                if (armor.method_7685().method_5927() == armorType + 2) {
                    int protection = armor.method_7687();
                    if (protection > bestProtection) {
                        bestProtection = protection;
                        bestSlot = i;
                    }
                }
            }
        }
        
        return bestSlot;
    }
}
