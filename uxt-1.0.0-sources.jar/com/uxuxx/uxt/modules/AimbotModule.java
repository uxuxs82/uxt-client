package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class AimbotModule extends Module {
    
    private Setting rangeSetting;
    private Setting fovSetting;
    
    public AimbotModule() {
        super("Aimbot");
        rangeSetting = new Setting("Range", 50.0, 20.0, 100.0, 10.0);
        fovSetting = new Setting("FOV", 90.0, 30.0, 180.0, 10.0);
        settings.add(rangeSetting);
        settings.add(fovSetting);
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null || client.field_1687 == null) return;
        
        class_1297 target = findClosestEntity(client);
        if (target != null) {
            class_243 targetPos = target.method_19538().method_1031(0, target.method_17682() * 0.9, 0);
            class_243 eyePos = client.field_1724.method_5836(1.0f);
            class_243 direction = targetPos.method_1020(eyePos).method_1029();
            
            float yaw = (float) Math.toDegrees(Math.atan2(direction.field_1350, direction.field_1352)) - 90;
            float pitch = (float) -Math.toDegrees(Math.asin(direction.field_1351));
            
            client.field_1724.field_6031 = yaw;
            client.field_1724.field_5965 = pitch;
        }
    }
    
    private class_1297 findClosestEntity(class_310 client) {
        class_1297 closest = null;
        double closestDist = rangeSetting.getValue();
        
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (entity == client.field_1724) continue;
            if (!(entity instanceof class_1309)) continue;
            
            double dist = client.field_1724.method_5739(entity);
            if (dist > rangeSetting.getValue()) continue;
            
            class_243 toEntity = entity.method_19538().method_1020(client.field_1724.method_19538()).method_1029();
            class_243 lookVec = client.field_1724.method_5828(1.0f);
            double angle = Math.toDegrees(Math.acos(lookVec.method_1026(toEntity)));
            
            if (angle > fovSetting.getValue() / 2) continue;
            
            if (dist < closestDist) {
                closestDist = dist;
                closest = entity;
            }
        }
        
        return closest;
    }
}
