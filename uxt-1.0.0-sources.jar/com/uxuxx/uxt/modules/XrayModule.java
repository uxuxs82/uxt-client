package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_310;

public class XrayModule extends Module {
    
    public static List<class_2248> xrayBlocks = new ArrayList<>();
    
    public XrayModule() {
        super("Xray");
        
        // Ores
        xrayBlocks.add(class_2246.field_10442);
        xrayBlocks.add(class_2246.field_10212);
        xrayBlocks.add(class_2246.field_10571);
        xrayBlocks.add(class_2246.field_10418);
        xrayBlocks.add(class_2246.field_10080);
        xrayBlocks.add(class_2246.field_10090);
        xrayBlocks.add(class_2246.field_10013);
        xrayBlocks.add(class_2246.field_22109);
        xrayBlocks.add(class_2246.field_10213);
        
        // Trees
        xrayBlocks.add(class_2246.field_10431);
        xrayBlocks.add(class_2246.field_10037);
        xrayBlocks.add(class_2246.field_10511);
        xrayBlocks.add(class_2246.field_10306);
        xrayBlocks.add(class_2246.field_10533);
        xrayBlocks.add(class_2246.field_10010);
    }
    
    @Override
    public void onEnable() {
        class_310 client = class_310.method_1551();
        if (client.field_1769 != null) {
            client.field_1769.method_3279();
        }
    }
    
    @Override
    public void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1769 != null) {
            client.field_1769.method_3279();
        }
    }
}
