package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public class ScaffoldModule extends Module {
    
    public ScaffoldModule() {
        super("Scaffold");
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null || client.field_1687 == null) return;
        
        class_2338 below = client.field_1724.method_24515().method_10074();
        class_2680 state = client.field_1687.method_8320(below);
        
        if (!state.method_26215()) return;
        
        // Find a block to place
        int slot = findBlockSlot(client);
        if (slot == -1) return;
        
        int prevSlot = client.field_1724.field_7514.field_7545;
        client.field_1724.field_7514.field_7545 = slot;
        
        // Find a neighbor block to click on
        class_2338[] neighbors = {
            below.method_10095(), below.method_10072(), below.method_10078(), below.method_10067(), below.method_10074()
        };
        class_2350[] dirs = {
            class_2350.field_11035, class_2350.field_11043, class_2350.field_11039, class_2350.field_11034, class_2350.field_11036
        };
        
        for (int i = 0; i < neighbors.length; i++) {
            class_2338 neighbor = neighbors[i];
            if (!client.field_1687.method_8320(neighbor).method_26215()) {
                class_243 hitVec = class_243.method_24953(neighbor).method_1019(class_243.method_24954(dirs[i].method_10163()).method_1021(0.5));
                class_3965 hit = new class_3965(hitVec, dirs[i], neighbor, false);
                
                float prevYaw = client.field_1724.field_6031;
                float prevPitch = client.field_1724.field_5965;
                client.field_1724.field_5965 = 80;
                
                client.field_1761.method_2896(client.field_1724, client.field_1687, class_1268.field_5808, hit);
                
                client.field_1724.field_6031 = prevYaw;
                client.field_1724.field_5965 = prevPitch;
                break;
            }
        }
        
        client.field_1724.field_7514.field_7545 = prevSlot;
    }
    
    private int findBlockSlot(class_310 client) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = client.field_1724.field_7514.method_5438(i);
            if (stack.method_7909() instanceof class_1747) {
                class_1747 bi = (class_1747) stack.method_7909();
                if (bi.method_7711() != class_2246.field_10124) {
                    return i;
                }
            }
        }
        return -1;
    }
}
