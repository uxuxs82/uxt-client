package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_1702;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4174;

public class AutoEatModule extends Module {
    
    private Setting hungerSetting;
    
    public AutoEatModule() {
        super("AutoEat");
        hungerSetting = new Setting("Hunger", 15.0, 5.0, 19.0, 1.0);
        settings.add(hungerSetting);
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        
        class_1702 hunger = client.field_1724.method_7344();
        if (hunger.method_7586() < hungerSetting.getValue()) {
            int foodSlot = findFoodSlot(client);
            if (foodSlot != -1) {
                int prevSlot = client.field_1724.field_7514.field_7545;
                client.field_1724.field_7514.field_7545 = foodSlot;
                client.field_1690.field_1904.method_23481(true);
                client.field_1724.field_7514.field_7545 = prevSlot;
            }
        } else {
            client.field_1690.field_1904.method_23481(false);
        }
    }
    
    private int findFoodSlot(class_310 client) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = client.field_1724.field_7514.method_5438(i);
            class_1792 item = stack.method_7909();
            class_4174 food = item.method_19264();
            if (food != null) {
                return i;
            }
        }
        return -1;
    }
}
