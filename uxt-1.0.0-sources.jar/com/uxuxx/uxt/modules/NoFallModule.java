package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_310;

public class NoFallModule extends Module {
    
    public NoFallModule() {
        super("NoFall");
    }
    
    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 != null) {
            client.field_1724.field_6017 = 0;
        }
    }
}
