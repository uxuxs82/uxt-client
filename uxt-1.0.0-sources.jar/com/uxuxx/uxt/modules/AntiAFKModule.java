package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_310;

public class AntiAFKModule extends Module {
    
    private int tickCounter = 0;
    
    public AntiAFKModule() {
        super("AntiAFK");
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        
        tickCounter++;
        if (tickCounter >= 200) {
            float random = (float) (Math.random() * 10 - 5);
            client.field_1724.field_6031 += random;
            tickCounter = 0;
        }
    }
}
