package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_310;

public class FullbrightModule extends Module {
    
    private double oldGamma;
    
    public FullbrightModule() {
        super("Fullbright");
    }
    
    @Override
    public void onEnable() {
        class_310 client = class_310.method_1551();
        oldGamma = client.field_1690.field_1840;
        client.field_1690.field_1840 = 16.0;
    }
    
    @Override
    public void onDisable() {
        class_310 client = class_310.method_1551();
        client.field_1690.field_1840 = oldGamma;
    }
}
