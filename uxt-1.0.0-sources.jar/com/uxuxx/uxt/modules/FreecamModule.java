package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_310;

public class FreecamModule extends Module {
    
    public FreecamModule() {
        super("Freecam");
    }
    
    @Override
    public void onEnable() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.field_5960 = true;
            client.field_1724.field_7503.field_7479 = true;
            client.field_1724.field_7503.field_7478 = true;
            client.field_1724.method_18800(0, 0, 0);
        }
    }
    
    @Override
    public void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.field_5960 = false;
            client.field_1724.field_7503.field_7479 = false;
            client.field_1724.field_7503.field_7478 = false;
        }
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        
        client.field_1724.field_5960 = true;
        client.field_1724.field_7503.field_7479 = true;
    }
}
