package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_310;

public class AutoSprintModule extends Module {
    
    public AutoSprintModule() {
        super("AutoSprint");
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        
        client.field_1724.method_5728(true);
    }
}
