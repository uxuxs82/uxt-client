package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_1536;
import net.minecraft.class_310;

public class AutoFishModule extends Module {
    
    private int waitTicks = 0;
    
    public AutoFishModule() {
        super("AutoFish");
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        
        class_1536 bobber = client.field_1724.field_7513;
        
        if (bobber != null) {
            waitTicks++;
            
            if (waitTicks > 20 && bobber.method_18798().method_1033() < 0.01) {
                // Fish caught, reel in
                client.field_1690.field_1904.method_23481(true);
                waitTicks = 0;
            }
        } else {
            // Cast
            if (waitTicks > 10) {
                client.field_1690.field_1904.method_23481(true);
                waitTicks = 0;
            } else {
                client.field_1690.field_1904.method_23481(false);
                waitTicks++;
            }
        }
    }
}
