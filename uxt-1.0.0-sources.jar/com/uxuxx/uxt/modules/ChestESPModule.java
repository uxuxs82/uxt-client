package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_310;

public class ChestESPModule extends Module {
    
    public static boolean enabled = false;
    public static List<class_2338> chestPositions = new ArrayList<>();
    
    public ChestESPModule() {
        super("ChestESP");
    }
    
    @Override
    public void onEnable() {
        enabled = true;
    }
    
    @Override
    public void onDisable() {
        enabled = false;
        chestPositions.clear();
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null || client.field_1687 == null) return;
        
        chestPositions.clear();
        class_2338 playerPos = client.field_1724.method_24515();
        
        for (int x = -50; x <= 50; x++) {
            for (int y = -50; y <= 50; y++) {
                for (int z = -50; z <= 50; z++) {
                    class_2338 pos = playerPos.method_10069(x, y, z);
                    if (client.field_1687.method_8320(pos).method_26204() == class_2246.field_10034) {
                        chestPositions.add(pos);
                    }
                }
            }
        }
    }
}
