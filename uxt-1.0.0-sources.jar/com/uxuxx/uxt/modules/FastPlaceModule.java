package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import java.lang.reflect.Field;
import net.minecraft.class_310;

public class FastPlaceModule extends Module {
    
    public FastPlaceModule() {
        super("FastPlace");
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1761 == null) return;
        
        try {
            Field field = client.field_1761.getClass().getDeclaredField("blockBreakingCooldown");
            field.setAccessible(true);
            field.setInt(client.field_1761, 0);
        } catch (Exception e) {
            // Ignore
        }
    }
}
