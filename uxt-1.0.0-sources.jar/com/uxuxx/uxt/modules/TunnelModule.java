package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_310;

public class TunnelModule extends Module {
    
    private Setting speedSetting;
    
    public TunnelModule() {
        super("Tunnel");
        speedSetting = new Setting("Speed", 1.0, 1.0, 5.0, 1.0);
        settings.add(speedSetting);
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        
        class_2338 playerPos = client.field_1724.method_24515();
        class_2338 target1 = playerPos.method_10093(client.field_1724.method_5735());
        class_2338 target2 = target1.method_10084();
        
        if (!client.field_1687.method_8320(target1).method_26215()) {
            client.field_1761.method_2910(target1, class_2350.field_11036);
            client.field_1724.method_6104(net.minecraft.class_1268.field_5808);
        }
        
        if (!client.field_1687.method_8320(target2).method_26215()) {
            client.field_1761.method_2910(target2, class_2350.field_11036);
            client.field_1724.method_6104(net.minecraft.class_1268.field_5808);
        }
    }
}
