package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;

public class KillAuraModule extends Module {
    
    private Setting rangeSetting;
    private int delay = 0;
    
    public KillAuraModule() {
        super("KillAura");
        rangeSetting = new Setting("Range", 4.0, 3.0, 6.0, 0.5);
        settings.add(rangeSetting);
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null || client.field_1687 == null) return;
        
        if (delay > 0) {
            delay--;
            return;
        }
        
        double range = rangeSetting.getValue();
        
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (entity instanceof class_1309 && entity != client.field_1724) {
                if (client.field_1724.method_5739(entity) <= range) {
                    if (entity instanceof class_1657 || entity instanceof class_1309) {
                        client.field_1761.method_2918(client.field_1724, entity);
                        client.field_1724.method_6104(class_1268.field_5808);
                        delay = 10;
                        break;
                    }
                }
            }
        }
    }
}
