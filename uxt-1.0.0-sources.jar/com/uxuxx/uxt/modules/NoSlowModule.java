package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_310;

public class NoSlowModule extends Module {
    
    public NoSlowModule() {
        super("NoSlow");
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        
        // Remove slowdown when using items (eating, blocking, etc)
        // This is usually handled by mixin, but we can set movement multiplier
        if (client.field_1724.method_6115()) {
            client.field_1724.field_3913.field_3905 *= 5.0f;
            client.field_1724.field_3913.field_3907 *= 5.0f;
        }
    }
}
