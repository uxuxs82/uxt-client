package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_1297;
import net.minecraft.class_1588;
import net.minecraft.class_310;

public class MobESPModule extends Module {
    
    private Setting rangeSetting;
    
    public MobESPModule() {
        super("MobESP");
        rangeSetting = new Setting("Range", 64.0, 32.0, 128.0, 16.0);
        settings.add(rangeSetting);
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null || client.field_1687 == null) return;
        
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (entity instanceof class_1588) {
                double dist = client.field_1724.method_5739(entity);
                if (dist <= rangeSetting.getValue()) {
                    entity.method_5834(true);
                } else {
                    entity.method_5834(false);
                }
            }
        }
    }
    
    @Override
    public void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1687 != null) {
            for (class_1297 entity : client.field_1687.method_18112()) {
                if (entity instanceof class_1588) {
                    entity.method_5834(false);
                }
            }
        }
    }
}
