package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_310;

public class AntiFireModule extends Module {
    
    public AntiFireModule() {
        super("AntiFire");
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        
        if (client.field_1724.method_5809()) {
            client.field_1724.method_20803(0);
        }
    }
}
