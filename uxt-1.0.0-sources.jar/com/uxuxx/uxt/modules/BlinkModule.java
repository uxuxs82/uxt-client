package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_2828;
import net.minecraft.class_310;

public class BlinkModule extends Module {
    
    public BlinkModule() {
        super("Blink");
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        
        // Blink effect - freeze position on server while moving client-side
        // Send old position packets
        if (client.method_1562() != null) {
            client.method_1562().method_2883(new class_2828.class_2829(
                client.field_1724.method_23317(), 
                client.field_1724.method_23318(), 
                client.field_1724.method_23321(), 
                client.field_1724.method_24828()
            ));
        }
    }
}
