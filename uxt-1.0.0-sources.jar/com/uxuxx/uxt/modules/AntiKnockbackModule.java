package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class AntiKnockbackModule extends Module {
    
    private Setting strengthSetting;
    
    public AntiKnockbackModule() {
        super("AntiKnockback");
        strengthSetting = new Setting("Strength", 50.0, 0.0, 100.0, 10.0);
        settings.add(strengthSetting);
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        
        double multiplier = 1.0 - (strengthSetting.getValue() / 100.0);
        class_243 velocity = client.field_1724.method_18798();
        client.field_1724.method_18800(velocity.field_1352 * multiplier, velocity.field_1351, velocity.field_1350 * multiplier);
    }
}
