package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_310;

public class SpeedModule extends Module {
    
    private Setting speedSetting;
    
    public SpeedModule() {
        super("Speed");
        speedSetting = new Setting("Speed", 2.0, 1.0, 5.0, 0.1);
        settings.add(speedSetting);
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        
        double speed = speedSetting.getValue();
        if (client.field_1724.field_3913.field_3905 != 0 || client.field_1724.field_3913.field_3907 != 0) {
            client.field_1724.method_18798().method_18805(speed, 1.0, speed);
        }
    }
}
