package com.uxuxx.uxt;

import com.uxuxx.uxt.gui.ClickGUI;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class UXTClient implements ClientModInitializer {
    
    public static ModuleManager moduleManager;
    public static ClickGUI clickGUI;
    
    private static class_304 guiKey;
    
    @Override
    public void onInitializeClient() {
        moduleManager = new ModuleManager();
        clickGUI = new ClickGUI();
        
        guiKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "Open GUI",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_TAB,
            "UXT"
        ));
        
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            moduleManager.onTick(client);
            
            while (guiKey.method_1436()) {
                client.method_1507(clickGUI);
            }
        });
    }
}
