package com.uxuxx.uxt.modules;

import com.uxuxx.uxt.Module;
import net.minecraft.class_1268;
import net.minecraft.class_310;

public class AutoClickerModule extends Module {
    
    private Setting cpsSetting;
    private int delay = 0;
    
    public AutoClickerModule() {
        super("AutoClicker");
        cpsSetting = new Setting("CPS", 12.0, 5.0, 20.0, 1.0);
        settings.add(cpsSetting);
    }
    
    @Override
    public void onTick(class_310 client) {
        if (!isEnabled() || client.field_1724 == null) return;
        
        if (delay > 0) {
            delay--;
            return;
        }
        
        if (client.field_1690.field_1886.method_1434()) {
            client.field_1761.method_2918(client.field_1724, client.field_1692);
            client.field_1724.method_6104(class_1268.field_5808);
            
            int cps = (int) cpsSetting.getValue();
            delay = 20 / cps;
        }
    }
}
